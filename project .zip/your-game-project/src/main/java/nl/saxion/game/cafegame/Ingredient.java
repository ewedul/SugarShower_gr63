package nl.saxion.game.cafegame;

public class Ingredient {
}