package nl.saxion.game.cafegame;

import com.badlogic.gdx.Input;
import nl.saxion.gameapp.GameApp;
import nl.saxion.gameapp.screens.ScalableGameScreen;
import java.util.ArrayList;

public class CafeGameScreen extends ScalableGameScreen {

    float bowlX = 500;
    ArrayList<SimpleIngredient> ingredients;
    float spawnTimer = 0;
    int lives = 3;
    boolean gameRunning = true;
    boolean showingOrder = true;
    float orderDisplayTimer = 0;

    // Track which needed ingredients haven't been caught yet
    ArrayList<String> missingIngredients;

    // LEVEL 1-5: BEVERAGES (Simple - catch ingredients)
    String[][] beverageRecipes = {
            {"Coffee", "milk", "coffee"},
            {"Hot Chocolate", "milk", "cocoa"},
            {"Matcha", "milk", "matcha"},
            {"Boba Tea", "boba", "milk", "tea"},
            {"Milkshake", "milk", "icecream"}
    };

    // LEVEL 6-10: PASTRY (More ingredients + decorations)
    String[][] pastryRecipes = {
            {"Cookies", "butter", "flour", "sugar", "egg"},
            {"Choco Cookies", "butter", "flour", "sugar", "egg", "choco chips"},
            {"Muffin", "butter", "flour", "sugar", "egg"},
            {"Frosted Muffin", "butter", "flour", "sugar", "egg", "frosting"},
            {"Macaron", "butter", "flour", "sugar", "egg"}
    };

    // LEVEL 11-15: CAKES (Base + icing + toppings)
    String[][] cakeRecipes = {
            {"Vanilla Cake", "egg", "flour", "sugar", "butter", "vanilla base", "vanilla icing"},
            {"Chocolate Cake", "egg", "flour", "sugar", "butter", "chocolate base", "chocolate icing"},
            {"Red Velvet Cake", "egg", "flour", "sugar", "butter", "red velvet base", "cream cheese icing"},
            {"Carrot Cake", "egg", "flour", "sugar", "butter", "carrot base", "cream cheese icing", "walnuts"},
            {"Custom Cake", "egg", "flour", "sugar", "butter", "strawberry base", "chocolate icing", "whipcream", "sprinkles"}
    };

    int currentLevel = 0;
    String[] currentRecipe;
    ArrayList<String> neededIngredients;
    ArrayList<String> caughtIngredients;

    // Ingredients for each phase
    String[] beverageIngredients = {"milk", "coffee", "cocoa", "matcha", "tea", "boba", "icecream"};
    String[] pastryIngredients = {"butter", "flour", "sugar", "egg", "choco chips", "frosting", "blueberry", "raspberry"};
    String[] cakeIngredients = {"egg", "flour", "sugar", "butter", "vanilla base", "chocolate base", "red velvet base",
            "carrot base", "strawberry base", "vanilla icing", "chocolate icing", "cream cheese icing",
            "whipcream", "sprinkles", "fruits", "choco chip", "walnuts"};

    String[] currentPhaseIngredients;
    float minSpawnRate = 0.5f;
    float maxSpawnRate = 2.0f;
    int phase = 1;
    int minIngredientsPerSpawn = 1;
    int maxIngredientsPerSpawn = 3;

    class SimpleIngredient {
        float x, y;
        boolean caught = false;
        boolean isObstacle = false;
        String type = "milk";
        boolean isNeeded = false;
        float fallSpeed = 150f; // Each ingredient can fall at different speeds
    }

    public CafeGameScreen() {
        super(1280, 720);
    }

    @Override
    public void show() {
        resetLevel();
    }

    private void resetLevel() {
        ingredients = new ArrayList<>();
        caughtIngredients = new ArrayList<>();
        missingIngredients = new ArrayList<>();
        lives = 3;
        gameRunning = true;
        showingOrder = true;
        orderDisplayTimer = 0;
        bowlX = getWorldWidth() / 2 - 50;

        // Determine which phase we're in
        if (currentLevel < 5) {
            phase = 1;
            currentRecipe = beverageRecipes[currentLevel];
            currentPhaseIngredients = beverageIngredients;
            minIngredientsPerSpawn = 1;
            maxIngredientsPerSpawn = 3;
            minSpawnRate = 1.0f;
            maxSpawnRate = 2.0f;
        } else if (currentLevel < 10) {
            phase = 2;
            currentRecipe = pastryRecipes[currentLevel - 5];
            currentPhaseIngredients = pastryIngredients;
            minIngredientsPerSpawn = 2;
            maxIngredientsPerSpawn = 4;
            minSpawnRate = 0.7f;
            maxSpawnRate = 1.5f;
        } else {
            phase = 3;
            currentRecipe = cakeRecipes[currentLevel - 10];
            currentPhaseIngredients = cakeIngredients;
            minIngredientsPerSpawn = 3;
            maxIngredientsPerSpawn = 5;
            minSpawnRate = 0.5f;
            maxSpawnRate = 1.2f;
        }

        neededIngredients = new ArrayList<>();

        // Add all ingredients needed (skip first element - it's the item name)
        for (int i = 1; i < currentRecipe.length; i++) {
            neededIngredients.add(currentRecipe[i]);
            missingIngredients.add(currentRecipe[i]); // Start with all needed ingredients missing
        }

        System.out.println("Level " + (currentLevel + 1) + " (Phase " + phase + "): Make " + currentRecipe[0]);
        System.out.println("Need: " + neededIngredients);
        System.out.println("Spawning " + minIngredientsPerSpawn + "-" + maxIngredientsPerSpawn + " ingredients at once");
    }

    private void nextLevel() {
        if (currentLevel < 14) {
            currentLevel++;
            resetLevel();
        } else {
            gameRunning = false;
        }
    }

    @Override
    public void render(float delta) {
        super.render(delta);

        if (showingOrder) {
            orderDisplayTimer += delta;
            showOrderDisplay();

            if (orderDisplayTimer > 3.0f) {
                showingOrder = false;
                // Set random first spawn time
                spawnTimer = (float) (Math.random() * (maxSpawnRate - minSpawnRate)) + minSpawnRate;
            }
            return;
        }

        if (!gameRunning) {
            showGameOver();
            return;
        }

        // Movement
        if (GameApp.isKeyPressed(Input.Keys.RIGHT)) {
            bowlX += 400 * delta;
        } else if (GameApp.isKeyPressed(Input.Keys.LEFT)) {
            bowlX -= 400 * delta;
        }
        if (bowlX < 0) bowlX = 0;
        if (bowlX > getWorldWidth() - 100) bowlX = getWorldWidth() - 100;

        // Auto-spawn with random timing and random number of ingredients
        spawnTimer += delta;
        if (spawnTimer > ((float) (Math.random() * (maxSpawnRate - minSpawnRate)) + minSpawnRate)) {
            spawnTimer = 0;

            // Random number of ingredients to spawn
            int numToSpawn = (int) (Math.random() * (maxIngredientsPerSpawn - minIngredientsPerSpawn + 1)) + minIngredientsPerSpawn;

            for (int i = 0; i < numToSpawn; i++) {
                spawnIngredient();
            }
            System.out.println("Spawned " + numToSpawn + " ingredients");
        }

        // Update ingredients with individual speeds
        for (int i = ingredients.size() - 1; i >= 0; i--) {
            SimpleIngredient ing = ingredients.get(i);
            if (!ing.caught) {
                ing.y -= ing.fallSpeed * delta;

                // Collision
                if (ing.y < 130 && ing.y > 50 &&
                        bowlX < ing.x + 40 && bowlX + 100 > ing.x) {
                    ing.caught = true;

                    if (ing.isObstacle) {
                        lives--;
                        System.out.println("Hit obstacle! Lives: " + lives);
                    } else if (neededIngredients.contains(ing.type)) {
                        caughtIngredients.add(ing.type);
                        missingIngredients.remove(ing.type); // Remove from missing list
                        System.out.println("Correct: " + ing.type + " | Progress: " + caughtIngredients + " | Missing: " + missingIngredients);
                        checkLevelComplete();
                    } else {
                        lives--;
                        System.out.println("Wrong ingredient: " + ing.type + " | Lives: " + lives);
                    }

                    if (lives <= 0) {
                        gameRunning = false;
                    }
                }

                // Remove if missed
                if (ing.y < -50) {
                    if (ing.isNeeded && !caughtIngredients.contains(ing.type)) {
                        System.out.println("Missed needed ingredient: " + ing.type + " - will respawn soon");
                    }
                    ingredients.remove(i);
                }
            } else {
                ingredients.remove(i);
            }
        }

        drawGame();

        if (GameApp.isKeyJustPressed(Input.Keys.ESCAPE)) {
            GameApp.switchScreen("MainMenuScreen");
        }
    }

    private void showOrderDisplay() {
        GameApp.clearScreen("blue-100");
        GameApp.startShapeRenderingFilled();

        String bgColor = "blue-200";
        String titleColor = "amber-500";

        if (phase == 2) {
            bgColor = "orange-200";
            titleColor = "gray-800";
        } else if (phase == 3) {
            bgColor = "pink-200";
            titleColor = "red-600";
        }

        // Draw order background
        GameApp.drawRect(300, 200, 700, 400, "white");
        GameApp.drawRect(310, 210, 680, 380, bgColor);

        // Draw title with phase info
        GameApp.drawRect(400, 500, 500, 60, titleColor);

        // Draw phase indicator
        String phaseName = "BEVERAGES";
        if (phase == 2) phaseName = "PASTRY";
        else if (phase == 3) phaseName = "CAKES";

        // Draw ingredients needed
        float yPos = 400;
        for (String ingredient : neededIngredients) {
            GameApp.drawRect(450, yPos, 40, 40, getIngredientColor(ingredient));
            GameApp.drawRect(500, yPos, 200, 40, "white");
            yPos -= 60;
        }

        GameApp.endShapeRendering();

        // Draw text
        GameApp.startSpriteRendering();
        GameApp.drawTextCentered("basic", phaseName + " - Level " + (currentLevel + 1), getWorldWidth()/2, 550, "white");
        GameApp.drawTextCentered("basic", "Make: " + currentRecipe[0], getWorldWidth()/2, 450, "black");

        float timeLeft = 3.0f - orderDisplayTimer;
        GameApp.drawTextCentered("basic", "Starting in: " + String.format("%.1f", timeLeft),
                getWorldWidth()/2, 100, "red-500");
        GameApp.endSpriteRendering();
    }

    private void spawnIngredient() {
        SimpleIngredient ing = new SimpleIngredient();

        // Find a position that's not too close to other ingredients
        int attempts = 0;
        boolean positionFound = false;

        while (!positionFound && attempts < 10) {
            ing.x = (float) (Math.random() * (getWorldWidth() - 100));
            ing.y = getWorldHeight();

            // Check if this position is too close to existing ingredients
            boolean tooClose = false;
            for (SimpleIngredient existing : ingredients) {
                float distance = Math.abs(existing.x - ing.x);
                if (distance < 60) { // Minimum spacing of 60 pixels
                    tooClose = true;
                    break;
                }
            }

            if (!tooClose) {
                positionFound = true;
            }
            attempts++;
        }

        // If no good position found after 10 attempts, use random position anyway
        if (!positionFound) {
            ing.x = (float) (Math.random() * (getWorldWidth() - 100));
            ing.y = getWorldHeight();
        }

        // Random fall speed for visual variety (150-250 pixels per second)
        ing.fallSpeed = (float) (Math.random() * 100) + 150f;

        // PRIORITY SYSTEM: Needed ingredients have higher chance
        double random = Math.random();

        if (random < 0.20) {
            // 20% chance: Obstacle
            ing.isObstacle = true;
            ing.type = "obstacle";
            ing.isNeeded = false;
        } else if (random < 0.60 && !missingIngredients.isEmpty()) {
            // 40% chance: Needed ingredient (if any are still missing)
            int randomIndex = (int)(Math.random() * missingIngredients.size());
            ing.type = missingIngredients.get(randomIndex);
            ing.isObstacle = false;
            ing.isNeeded = true;
        } else {
            // 40% chance: Random ingredient from current phase
            ing.isObstacle = false;
            ing.isNeeded = false;
            int randomIndex = (int)(Math.random() * currentPhaseIngredients.length);
            ing.type = currentPhaseIngredients[randomIndex];
        }

        ingredients.add(ing);
    }

    private void checkLevelComplete() {
        for (String needed : neededIngredients) {
            if (!caughtIngredients.contains(needed)) {
                return;
            }
        }
        System.out.println("Level " + (currentLevel + 1) + " complete! Going to next level...");
        nextLevel();
    }

    private void drawGame() {
        String bgColor = "pink-200";
        if (phase == 2) bgColor = "orange-100";
        else if (phase == 3) bgColor = "purple-100";

        GameApp.clearScreen(bgColor);
        GameApp.startShapeRenderingFilled();

        for (SimpleIngredient ing : ingredients) {
            if (!ing.caught) {
                String color = ing.isObstacle ? "red-500" : getIngredientColor(ing.type);
                GameApp.drawRect(ing.x, ing.y, 40, 40, color);

                // Highlight needed ingredients with a border
                if (ing.isNeeded) {
                    GameApp.drawRect(ing.x - 2, ing.y - 2, 44, 44, "green-500");
                }
            }
        }

        GameApp.drawRect(bowlX, 50, 100, 80, "blue-500");
        GameApp.drawRect(10, getWorldHeight() - 60, 200, 40, "white");
        GameApp.drawRect(10, getWorldHeight() - 110, 300, 40, "white");
        GameApp.drawRect(10, getWorldHeight() - 160, 400, 40, "white");

        GameApp.endShapeRendering();

        GameApp.startSpriteRendering();
        String phaseText = "Beverages";
        if (phase == 2) phaseText = "Pastry";
        else if (phase == 3) phaseText = "Cakes";

        GameApp.drawText("basic", "Phase: " + phaseText, 20, getWorldHeight() - 180, "black");
        GameApp.drawText("basic", "Lives: " + lives, 20, getWorldHeight() - 30, "black");
        GameApp.drawText("basic", "Level: " + (currentLevel + 1) + " - " + currentRecipe[0], 20, getWorldHeight() - 80, "black");
        GameApp.drawText("basic", "Needed: " + String.join(", ", neededIngredients), 20, getWorldHeight() - 130, "black");
        GameApp.drawText("basic", "Caught: " + String.join(", ", caughtIngredients), 20, getWorldHeight() - 150, "green-700");
        GameApp.drawText("basic", "Missing: " + String.join(", ", missingIngredients), 20, getWorldHeight() - 170, "red-700");
        GameApp.endSpriteRendering();
    }

    private void showGameOver() {
        GameApp.clearScreen("pink-200");
        GameApp.startShapeRenderingFilled();

        if (currentLevel >= 14) {
            GameApp.drawRect(400, 300, 500, 200, "green-300");
            GameApp.startSpriteRendering();
            GameApp.drawTextCentered("basic", "YOU WIN!", getWorldWidth()/2, 400, "black");
            GameApp.drawTextCentered("basic", "All levels completed!", getWorldWidth()/2, 350, "black");
            GameApp.drawTextCentered("basic", "Press M for main menu", getWorldWidth()/2, 300, "black");
            GameApp.endSpriteRendering();
        } else {
            GameApp.drawRect(400, 300, 500, 200, "red-300");
            GameApp.startSpriteRendering();
            GameApp.drawTextCentered("basic", "GAME OVER", getWorldWidth()/2, 400, "black");
            GameApp.drawTextCentered("basic", "Level: " + (currentLevel + 1) + " - " + currentRecipe[0], getWorldWidth()/2, 350, "black");
            GameApp.drawTextCentered("basic", "Press R to retry this level", getWorldWidth()/2, 300, "black");
            GameApp.drawTextCentered("basic", "Press M for main menu", getWorldWidth()/2, 250, "black");
            GameApp.endSpriteRendering();
        }

        GameApp.endShapeRendering();

        if (GameApp.isKeyJustPressed(Input.Keys.R)) {
            resetLevel();
        }
        if (GameApp.isKeyJustPressed(Input.Keys.M)) {
            currentLevel = 0;
            GameApp.switchScreen("MainMenuScreen");
        }
    }

    private String getIngredientColor(String type) {
        // Beverage colors
        if (type.equals("milk")) return "white";
        if (type.equals("coffee")) return "gray-800";
        if (type.equals("cocoa")) return "gray-700";
        if (type.equals("matcha")) return "green-500";
        if (type.equals("tea")) return "green-300";
        if (type.equals("boba")) return "black";
        if (type.equals("icecream")) return "pink-300";

        // Pastry colors
        if (type.equals("butter")) return "yellow-300";
        if (type.equals("flour")) return "gray-200";
        if (type.equals("sugar")) return "white";
        if (type.equals("egg")) return "yellow-500";
        if (type.equals("choco chips")) return "gray-900";
        if (type.equals("frosting")) return "pink-200";
        if (type.equals("blueberry")) return "blue-600";
        if (type.equals("raspberry")) return "red-600";

        // Cake colors
        if (type.equals("vanilla base")) return "yellow-200";
        if (type.equals("chocolate base")) return "gray-900";
        if (type.equals("red velvet base")) return "red-700";
        if (type.equals("carrot base")) return "orange-500";
        if (type.equals("strawberry base")) return "pink-400";
        if (type.equals("vanilla icing")) return "white";
        if (type.equals("chocolate icing")) return "gray-800";
        if (type.equals("cream cheese icing")) return "yellow-100";
        if (type.equals("whipcream")) return "white";
        if (type.equals("sprinkles")) return "rainbow";
        if (type.equals("fruits")) return "red-500";
        if (type.equals("choco chip")) return "gray-900";
        if (type.equals("walnuts")) return "gray-800";

        return "gray-500";
    }

    @Override
    public void hide() {
    }
}