package nl.saxion.game.cafegame;

import com.badlogic.gdx.Input;
import nl.saxion.gameapp.GameApp;
import nl.saxion.gameapp.screens.ScalableGameScreen;

public class MainMenuScreen extends ScalableGameScreen {
    public MainMenuScreen() {
        super(1280, 720);
    }

    @Override
    public void show() {
        GameApp.addFont("basic", "fonts/basic.ttf", 30);
    }

    @Override
    public void render(float delta) {
        super.render(delta);

        if (GameApp.isKeyJustPressed(Input.Keys.ENTER)) {
            GameApp.switchScreen("CafeGameScreen");
        }

        GameApp.clearScreen("pink-300");
        GameApp.startSpriteRendering();
        GameApp.drawTextCentered("basic", "VIRTUAL CAFE", getWorldWidth()/2, 500, "amber-500");
        GameApp.drawTextCentered("basic", "Press ENTER to Start", getWorldWidth()/2, 400, "white");
        GameApp.drawTextCentered("basic", "Use LEFT/RIGHT arrows to move", getWorldWidth()/2, 350, "white");
        GameApp.drawTextCentered("basic", "Catch ingredients, avoid red obstacles", getWorldWidth()/2, 300, "white");
        GameApp.endSpriteRendering();
    }

    @Override
    public void hide() {
        GameApp.disposeFont("basic");
    }
}