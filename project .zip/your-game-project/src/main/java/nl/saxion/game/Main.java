package nl.saxion.game;

import nl.saxion.game.cafegame.CafeGameScreen;
import nl.saxion.game.cafegame.MainMenuScreen;
import nl.saxion.gameapp.GameApp;

public class Main {
    public static void main(String[] args) {
        try {
            GameApp.addScreen("MainMenuScreen", new MainMenuScreen());
            GameApp.addScreen("CafeGameScreen", new CafeGameScreen());
            GameApp.start("Virtual Cafe", 800, 450, 60, false, "MainMenuScreen");
        } catch (Exception e) {
            System.err.println("Game crashed!");
            e.printStackTrace();
        }
    }
}